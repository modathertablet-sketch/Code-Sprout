import React from 'react'

import Script from 'dangerous-html/react'

import './footer.css'

const Footer = (props) => {
  return (
    <div className="footer-container1">
      <div className="footer-container2">
        <div className="footer-container3">
          <Script
            html={`<style>
@media (prefers-reduced-motion: reduce) {
.footer-decorative-top {
  animation: none;
}
.footer-social-link, .footer-nav-link, .footer-newsletter-input, .footer-newsletter-button svg, .footer-legal-link {
  transition: none;
}
.footer-social-link:hover {
  transform: none;
}
.footer-nav-link:hover {
  transform: none;
}
.footer-newsletter-button:hover svg {
  transform: none;
}
}
</style>`}
          ></Script>
        </div>
      </div>
      <footer className="footer">
        <div className="footer-decorative-top"></div>
        <div className="footer-container">
          <div className="footer-content">
            <div className="footer-brand-section">
              <div className="footer-brand">
                <div className="footer-logo">
                  <svg
                    width="32"
                    xmlns="http://www.w3.org/2000/svg"
                    height="32"
                    viewBox="0 0 24 24"
                  >
                    <path
                      d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <span className="footer-logo-text">CodeSprout</span>
                </div>
                <p className="footer-tagline">
                  {' '}
                  Empowering beginners to grow into confident developers through
                  clear, practical programming tutorials.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
                <div className="footer-social">
                  <a href="#">
                    <div aria-label="GitHub" className="footer-social-link">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <g
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5c.08-1.25-.27-2.48-1-3.5c.28-1.15.28-2.35 0-3.5c0 0-1 0-3 1.5c-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.4 5.4 0 0 0 4 9c0 3.5 3 5.5 6 5.5c-.39.49-.68 1.05-.85 1.65S8.93 17.38 9 18v4"></path>
                          <path d="M9 18c-4.51 2-5-2-7-2"></path>
                        </g>
                      </svg>
                    </div>
                  </a>
                  <a href="#">
                    <div aria-label="Twitter" className="footer-social-link">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6c2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4c-.9-4.2 4-6.6 7-3.8c1.1 0 3-1.2 3-1.2"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                    </div>
                  </a>
                  <a href="#">
                    <div aria-label="LinkedIn" className="footer-social-link">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <g
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2a2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6M2 9h4v12H2z"></path>
                          <circle r="2" cx="4" cy="4"></circle>
                        </g>
                      </svg>
                    </div>
                  </a>
                  <a href="#">
                    <div aria-label="YouTube" className="footer-social-link">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <g
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M2.5 17a24.1 24.1 0 0 1 0-10a2 2 0 0 1 1.4-1.4a49.6 49.6 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.1 24.1 0 0 1 0 10a2 2 0 0 1-1.4 1.4a49.6 49.6 0 0 1-16.2 0A2 2 0 0 1 2.5 17"></path>
                          <path d="m10 15l5-3l-5-3z"></path>
                        </g>
                      </svg>
                    </div>
                  </a>
                </div>
              </div>
            </div>
            <div className="footer-links-grid">
              <div className="footer-column">
                <div className="footer-column-header">
                  <svg
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    height="20"
                    viewBox="0 0 24 24"
                  >
                    <path
                      d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3 className="footer-column-title">Tutorials</h3>
                </div>
                <ul className="footer-nav-list">
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Python Basics</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>JavaScript Fundamentals</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>HTML &amp; CSS Guide</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>React for Beginners</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Java Programming</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>SQL Database Basics</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Git Version Control</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>TypeScript Intro</span>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
              <div className="footer-column">
                <div className="footer-column-header">
                  <svg
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    height="20"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2"></path>
                      <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0m1 7v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path>
                    </g>
                  </svg>
                  <h3 className="footer-column-title">Learning Paths</h3>
                </div>
                <ul className="footer-nav-list">
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Frontend Developer</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Backend Developer</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Full Stack Developer</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Mobile App Developer</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Data Scientist</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>DevOps Engineer</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Web3 Developer</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Game Developer</span>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
              <div className="footer-column">
                <div className="footer-column-header">
                  <svg
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    height="20"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3.128a4 4 0 0 1 0 7.744M22 21v-2a4 4 0 0 0-3-3.87"></path>
                      <circle r="4" cx="9" cy="7"></circle>
                    </g>
                  </svg>
                  <h3 className="footer-column-title">Community</h3>
                </div>
                <ul className="footer-nav-list">
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Discussion Forums</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Code Challenges</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Student Showcase</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Study Groups</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Mentorship Program</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Success Stories</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Contributing Guide</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Code of Conduct</span>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
              <div className="footer-column">
                <div className="footer-column-header">
                  <svg
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    height="20"
                    viewBox="0 0 24 24"
                  >
                    <path
                      d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <h3 className="footer-column-title">Resources</h3>
                </div>
                <ul className="footer-nav-list">
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Documentation Hub</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Cheat Sheets</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Project Templates</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Code Snippets</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Video Library</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>eBooks &amp; Guides</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Tool Recommendations</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Career Resources</span>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
              <div className="footer-column">
                <div className="footer-column-header">
                  <svg
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    height="20"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m22 7l-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path>
                      <rect x="2" y="4" rx="2" width="20" height="16"></rect>
                    </g>
                  </svg>
                  <h3 className="footer-column-title">Company</h3>
                </div>
                <ul className="footer-nav-list">
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>About CodeSprout</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Our Mission</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Meet the Team</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Blog &amp; News</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Careers</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Press Kit</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Contact Us</span>
                      </div>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div className="footer-nav-link">
                        <span>Partner With Us</span>
                      </div>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="footer-newsletter">
            <div className="footer-newsletter-content">
              <div className="footer-newsletter-info">
                <h3 className="footer-newsletter-title">Stay Updated</h3>
                <p className="footer-newsletter-description">
                  {' '}
                  Get weekly programming tips, new tutorials, and exclusive
                  learning resources delivered to your inbox.
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </p>
              </div>
              <form
                action="/subscribe"
                method="POST"
                data-form-id="db708cfe-e18c-4853-826e-3fe3b0ac8ae1"
                className="footer-newsletter-form"
              >
                <div className="footer-newsletter-input-wrapper">
                  <svg
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    height="20"
                    viewBox="0 0 24 24"
                  >
                    <g
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m22 7l-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path>
                      <rect x="2" y="4" rx="2" width="20" height="16"></rect>
                    </g>
                  </svg>
                  <input
                    type="email"
                    id="thq_textinput_FW2z"
                    name="textinput"
                    required="true"
                    placeholder="Enter your email address"
                    data-form-field-id="thq_textinput_FW2z"
                    className="footer-newsletter-input"
                  />
                </div>
                <button
                  id="thq_button_heLX"
                  name="button"
                  type="submit"
                  data-form-field-id="thq_button_heLX"
                  className="btn footer-newsletter-button btn-primary"
                >
                  <span>Subscribe</span>
                  <svg
                    width="18"
                    xmlns="http://www.w3.org/2000/svg"
                    height="18"
                    viewBox="0 0 24 24"
                  >
                    <path
                      d="M5 12h14m-7-7l7 7l-7 7"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                </button>
              </form>
            </div>
          </div>
          <div className="footer-bottom">
            <div className="footer-bottom-content">
              <div className="footer-copyright">
                <p>&amp;copy; 2025 CodeSprout. All rights reserved.</p>
              </div>
              <nav aria-label="Legal navigation" className="footer-legal">
                <a href="#">
                  <div className="footer-legal-link">
                    <span>Privacy Policy</span>
                  </div>
                </a>
                <span className="footer-legal-separator"></span>
                <a href="#">
                  <div className="footer-legal-link">
                    <span>Terms of Service</span>
                  </div>
                </a>
                <span className="footer-legal-separator"></span>
                <a href="#">
                  <div className="footer-legal-link">
                    <span>Cookie Settings</span>
                  </div>
                </a>
                <span className="footer-legal-separator"></span>
                <a href="#">
                  <div className="footer-legal-link">
                    <span>Accessibility</span>
                  </div>
                </a>
              </nav>
            </div>
          </div>
        </div>
      </footer>
      <div className="footer-container4">
        <div className="footer-container5">
          <Script
            html={`<style>
        @keyframes shimmer {0%,100% {background-position: 0% 50%;}
50% {background-position: 100% 50%;}}
        </style> `}
          ></Script>
        </div>
      </div>
    </div>
  )
}

export default Footer
