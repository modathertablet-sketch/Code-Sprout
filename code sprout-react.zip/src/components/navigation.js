import React from 'react'

import Script from 'dangerous-html/react'

import './navigation.css'

const Navigation = (props) => {
  return (
    <div className="navigation-container1">
      <nav className="navigation">
        <div className="navigation-container">
          <a href="#">
            <div className="navigation-logo">
              <svg
                width="32"
                xmlns="http://www.w3.org/2000/svg"
                height="32"
                viewBox="0 0 24 24"
                className="navigation-logo-icon"
              >
                <path
                  d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <span className="section-title">CodeSprout</span>
            </div>
          </a>
          <div className="navigation-links">
            <a href="#">
              <div className="navigation-link">
                <span>Tutorials</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>Courses</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>Blog</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>Community</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>About</span>
              </div>
            </a>
            <button className="btn navigation-cta btn-primary">
              Start Learning
            </button>
          </div>
          <button
            aria-label="Toggle menu"
            aria-expanded="false"
            className="navigation-toggle"
          >
            <svg
              width="24"
              xmlns="http://www.w3.org/2000/svg"
              height="24"
              viewBox="0 0 24 24"
            >
              <path
                d="M4 5h16M4 12h16M4 19h16"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
          </button>
        </div>
        <div className="navigation-mobile-overlay">
          <div className="navigation-mobile-header">
            <a href="#">
              <div className="navigation-logo">
                <svg
                  width="32"
                  xmlns="http://www.w3.org/2000/svg"
                  height="32"
                  viewBox="0 0 24 24"
                  className="navigation-logo-icon"
                >
                  <path
                    d="m16 18l6-6l-6-6M8 6l-6 6l6 6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span className="section-title">CodeSprout</span>
              </div>
            </a>
            <button aria-label="Close menu" className="navigation-close">
              <svg
                width="28"
                xmlns="http://www.w3.org/2000/svg"
                height="28"
                viewBox="0 0 24 24"
              >
                <path
                  d="M18 6L6 18M6 6l12 12"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
          </div>
          <div className="navigation-mobile-content">
            <a href="#">
              <div className="navigation-mobile-link">
                <span>Tutorials</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>Courses</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>Blog</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>Community</span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>About</span>
              </div>
            </a>
            <button className="btn btn-lg navigation-mobile-cta btn-primary">
              {' '}
              Start Learning
              <span
                dangerouslySetInnerHTML={{
                  __html: ' ',
                }}
              />
            </button>
          </div>
        </div>
      </nav>
      <div className="navigation-container2">
        <div className="navigation-container3">
          <Script
            html={`<style>
@media (prefers-reduced-motion: reduce) {
.navigation, .navigation-logo, .navigation-link, .navigation-link::after, .navigation-toggle, .navigation-close, .navigation-mobile-overlay, .navigation-mobile-link, .navigation-mobile-cta {
  transition: none;
  animation: none;
}
.navigation-mobile-link, .navigation-mobile-cta {
  opacity: 1;
  transform: none;
}
}
</style>`}
          ></Script>
        </div>
      </div>
      <div className="navigation-container4">
        <div className="navigation-container5">
          <Script
            html={`<script defer data-name="navigation-menu-toggle">
(function(){
  const navigationToggle = document.querySelector(".navigation-toggle")
  const navigationClose = document.querySelector(".navigation-close")
  const navigationMobileOverlay = document.querySelector(
    ".navigation-mobile-overlay"
  )
  const navigationMobileLinks = document.querySelectorAll(
    ".navigation-mobile-link"
  )

  function openMobileMenu() {
    navigationMobileOverlay.classList.add("navigation-mobile-active")
    navigationToggle.setAttribute("aria-expanded", "true")
    document.body.style.overflow = "hidden"
  }

  function closeMobileMenu() {
    navigationMobileOverlay.classList.remove("navigation-mobile-active")
    navigationToggle.setAttribute("aria-expanded", "false")
    document.body.style.overflow = ""
  }

  navigationToggle.addEventListener("click", openMobileMenu)
  navigationClose.addEventListener("click", closeMobileMenu)

  navigationMobileLinks.forEach((link) => {
    link.addEventListener("click", closeMobileMenu)
  })

  navigationMobileOverlay.addEventListener("click", (e) => {
    if (e.target === navigationMobileOverlay) {
      closeMobileMenu()
    }
  })
})()
</script>`}
          ></Script>
        </div>
      </div>
    </div>
  )
}

export default Navigation
